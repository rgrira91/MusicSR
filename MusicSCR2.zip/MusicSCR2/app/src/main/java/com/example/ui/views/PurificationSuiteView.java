package com.example.ui.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.annotation.Nullable;
import java.util.Locale;

/**
 * Hardware-styled AUDIO PROCESSING • PURIFICATION SUITE rack unit:
 *  - 5 Illuminated Faders (BASS, LOW MID, MID, HIGH MID, TREBLE) synced to 10-Band EQ
 *  - Dynamic Range COMPRESSOR (RATIO 1:1..8:1, THRESHOLD -30..0dB) + live gain reduction glow
 *  - NOISE GATE & NOISE REDUCTION hardware toggle switches
 *  - BASS BOOST (+0..+12dB), TREBLE CLARITY (+0..+12dB), STEREO WIDTH (0..200%),
 *    LIMITER (-12..0dB), AUTO GAIN toggle switch, HPF (20..250Hz), LPF (8k..22kHz)
 */
public class PurificationSuiteView extends View {

    public interface SuiteListener {
        void onFaderChanged(int groupIndex, float gainDb);
        void onCompressorChanged(float ratio, float thresholdDb);
        void onNoiseGateToggled(boolean enabled);
        void onNoiseReductionToggled(boolean enabled);
        void onPurificationBassChanged(float boostDb);
        void onTrebleClarityChanged(float clarityDb);
        void onStereoWidthChanged(int widthPercent);
        void onLimiterChanged(float ceilingDb);
        void onAutoGainToggled(boolean enabled);
        void onHpfChanged(int hpfHz);
        void onLpfChanged(int lpfHz);
    }

    private static final String[] FADER_LABELS = {"BASS", "LOW MID", "MID", "HIGH MID", "TREBLE"};
    private static final int[] FADER_COLORS = {
            0xFF3B82F6, // BASS - Electric Blue
            0xFF22D3EE, // LOW MID - Cyan
            0xFFD946EF, // MID - Violet Pink
            0xFFEC4899, // HIGH MID - Magenta
            0xFFFB7185  // TREBLE - Rose Coral
    };

    private static final int TARGET_NONE = -1;
    private static final int TARGET_FADER_BASE = 0; // 0..4
    private static final int TARGET_KNOB_RATIO = 10;
    private static final int TARGET_KNOB_THRESH = 11;
    private static final int TARGET_KNOB_BASS_BOOST = 12;
    private static final int TARGET_KNOB_TREBLE_CLARITY = 13;
    private static final int TARGET_KNOB_STEREO_WIDTH = 14;
    private static final int TARGET_KNOB_LIMITER = 15;
    private static final int TARGET_KNOB_HPF = 16;
    private static final int TARGET_KNOB_LPF = 17;
    private static final int TARGET_SW_NOISE_GATE = 20;
    private static final int TARGET_SW_NOISE_REDUCTION = 21;
    private static final int TARGET_SW_AUTO_GAIN = 22;

    private final Paint outerGlassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint outerRimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint headerPillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint headerTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subPanelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subPanelBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dividerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Paint trackBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trackGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint capBodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint capBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint capLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Paint labelSmallPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valueTinyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sectionTitlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Paint knobMetalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobRimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobPointerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobDotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Paint swSlotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint swKnobPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ledPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ledHaloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final RectF outerRect = new RectF();
    private final RectF topHeaderRect = new RectF();
    private final RectF faderBayRect = new RectF();
    private final RectF compBayRect = new RectF();
    private final RectF bottomBayRect = new RectF();
    private final RectF footerRect = new RectF();
    private final RectF tempRect = new RectF();

    private final RectF[] faderHitRects = new RectF[5];
    private final RectF ratioHitRect = new RectF();
    private final RectF threshHitRect = new RectF();
    private final RectF noiseGateHitRect = new RectF();
    private final RectF noiseRedHitRect = new RectF();
    private final RectF bassBoostHitRect = new RectF();
    private final RectF trebleClarityHitRect = new RectF();
    private final RectF stereoWidthHitRect = new RectF();
    private final RectF limiterHitRect = new RectF();
    private final RectF autoGainHitRect = new RectF();
    private final RectF hpfHitRect = new RectF();
    private final RectF lpfHitRect = new RectF();

    // State
    private final float[] faderDb = {0f, 0f, 0f, 0f, 0f}; // -12..+12 dB
    private float compRatio = 3.0f;           // 1..8
    private float compThresholdDb = -12.0f;   // -30..0
    private boolean noiseGateOn = true;
    private boolean noiseReductionOn = true;
    private float bassBoostDb = 3.0f;         // 0..12
    private float trebleClarityDb = 2.5f;     // 0..12
    private int stereoWidthPercent = 120;     // 0..200
    private float limiterCeilingDb = -1.0f;   // -12..0
    private boolean autoGainOn = true;
    private int hpfHz = 80;                   // 20..250
    private int lpfHz = 18000;                // 8000..22000

    private int bitDepth = 24;
    private float liveCompReductionDb = 0f;
    private boolean limiterEngaged = false;

    private float density = 1f;
    private int activeTarget = TARGET_NONE;
    private float lastTouchY = 0f;
    private long lastTapMs = 0L;
    private int lastTapTarget = TARGET_NONE;
    private SuiteListener listener;

    public PurificationSuiteView(Context context) {
        super(context);
        init(context);
    }

    public PurificationSuiteView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PurificationSuiteView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        density = context.getResources().getDisplayMetrics().density;
        for (int i = 0; i < 5; i++) faderHitRects[i] = new RectF();

        outerGlassPaint.setStyle(Paint.Style.FILL);
        outerRimPaint.setStyle(Paint.Style.STROKE);
        outerRimPaint.setStrokeWidth(2.0f * density);

        headerPillPaint.setStyle(Paint.Style.FILL);
        headerPillPaint.setColor(0xD80A0F1E);

        headerTextPaint.setTextAlign(Paint.Align.CENTER);
        headerTextPaint.setColor(0xFF67E8F9);
        headerTextPaint.setTextSize(8.2f * density);
        headerTextPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        headerTextPaint.setLetterSpacing(0.10f);

        subPanelPaint.setStyle(Paint.Style.FILL);
        subPanelPaint.setColor(0x9A0A0D1A);

        subPanelBorderPaint.setStyle(Paint.Style.STROKE);
        subPanelBorderPaint.setStrokeWidth(1.0f * density);
        subPanelBorderPaint.setColor(0x5594A3B8);

        dividerPaint.setStyle(Paint.Style.STROKE);
        dividerPaint.setStrokeWidth(1.0f * density);
        dividerPaint.setColor(0x44CBD5E1);

        trackBgPaint.setStyle(Paint.Style.FILL);
        trackBgPaint.setColor(0xFF05070F);

        trackGlowPaint.setStyle(Paint.Style.FILL);

        tickPaint.setStyle(Paint.Style.STROKE);
        tickPaint.setStrokeWidth(0.9f * density);
        tickPaint.setColor(0x55CBD5E1);

        capBodyPaint.setStyle(Paint.Style.FILL);
        capBorderPaint.setStyle(Paint.Style.STROKE);
        capBorderPaint.setStrokeWidth(1.0f * density);
        capBorderPaint.setColor(0xDDE2E8F0);
        capLinePaint.setStyle(Paint.Style.STROKE);
        capLinePaint.setStrokeWidth(1.2f * density);
        capLinePaint.setColor(0xFFFFFFFF);

        labelSmallPaint.setTextAlign(Paint.Align.CENTER);
        labelSmallPaint.setColor(0xFFE2E8F0);
        labelSmallPaint.setTextSize(6.6f * density);
        labelSmallPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        labelSmallPaint.setLetterSpacing(0.04f);

        valueTinyPaint.setTextAlign(Paint.Align.CENTER);
        valueTinyPaint.setColor(0xFF94A3B8);
        valueTinyPaint.setTextSize(6.3f * density);
        valueTinyPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));

        sectionTitlePaint.setTextAlign(Paint.Align.CENTER);
        sectionTitlePaint.setColor(0xFFF1F5F9);
        sectionTitlePaint.setTextSize(7.4f * density);
        sectionTitlePaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        sectionTitlePaint.setLetterSpacing(0.08f);

        knobShadowPaint.setStyle(Paint.Style.FILL);
        knobShadowPaint.setColor(0x9903050C);
        knobMetalPaint.setStyle(Paint.Style.FILL);
        knobRimPaint.setStyle(Paint.Style.STROKE);
        knobRimPaint.setStrokeWidth(1.2f * density);
        knobPointerPaint.setStyle(Paint.Style.STROKE);
        knobPointerPaint.setStrokeCap(Paint.Cap.ROUND);
        knobPointerPaint.setStrokeWidth(1.8f * density);
        knobPointerPaint.setColor(0xFF0F172A);
        knobDotPaint.setStyle(Paint.Style.FILL);

        swSlotPaint.setStyle(Paint.Style.FILL);
        swKnobPaint.setStyle(Paint.Style.FILL);
        swKnobPaint.setColor(0xFFF1F5F9);
        ledPaint.setStyle(Paint.Style.FILL);
        ledHaloPaint.setStyle(Paint.Style.FILL);
    }

    public void setSuiteListener(SuiteListener listener) {
        this.listener = listener;
    }

    public void syncFromEngine(
            float[] fiveBandsDb,
            float compRatio,
            float compThreshDb,
            boolean noiseGateOn,
            boolean noiseReductionOn,
            float bassBoostDb,
            float trebleClarityDb,
            int stereoWidthPercent,
            float limiterCeilingDb,
            boolean autoGainOn,
            int hpfHz,
            int lpfHz,
            int bitDepth) {
        if (fiveBandsDb != null) {
            for (int i = 0; i < Math.min(5, fiveBandsDb.length); i++) {
                this.faderDb[i] = Math.max(-12f, Math.min(12f, fiveBandsDb[i]));
            }
        }
        this.compRatio = Math.max(1f, Math.min(8f, compRatio));
        this.compThresholdDb = Math.max(-30f, Math.min(0f, compThreshDb));
        this.noiseGateOn = noiseGateOn;
        this.noiseReductionOn = noiseReductionOn;
        this.bassBoostDb = Math.max(0f, Math.min(12f, bassBoostDb));
        this.trebleClarityDb = Math.max(0f, Math.min(12f, trebleClarityDb));
        this.stereoWidthPercent = Math.max(0, Math.min(200, stereoWidthPercent));
        this.limiterCeilingDb = Math.max(-12f, Math.min(0f, limiterCeilingDb));
        this.autoGainOn = autoGainOn;
        this.hpfHz = Math.max(20, Math.min(250, hpfHz));
        this.lpfHz = Math.max(8000, Math.min(22000, lpfHz));
        if (bitDepth > 0) this.bitDepth = bitDepth;
        invalidate();
    }

    public void updateLiveStatus(float compReductionDb, boolean limiterEngaged, int bitDepth) {
        boolean changed = Math.abs(this.liveCompReductionDb - compReductionDb) > 0.25f
                || this.limiterEngaged != limiterEngaged
                || this.bitDepth != bitDepth;
        this.liveCompReductionDb = compReductionDb;
        this.limiterEngaged = limiterEngaged;
        if (bitDepth > 0) this.bitDepth = bitDepth;
        if (changed && isShown()) {
            postInvalidateOnAnimation();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0 || h <= 0) return;

        outerGlassPaint.setShader(new LinearGradient(
                0, 0, w, h,
                new int[]{0xD8151B2E, 0xE60B0F1B, 0xD822142D},
                null,
                Shader.TileMode.CLAMP
        ));
        outerRimPaint.setShader(new LinearGradient(
                0, 0, w, h,
                new int[]{0xFF67E8F9, 0xFFE2E8F0, 0xFFF472B6, 0xFF38BDF8},
                null,
                Shader.TileMode.CLAMP
        ));
        knobMetalPaint.setShader(new LinearGradient(
                0, 0, 22f * density, 22f * density,
                new int[]{0xFFF8FAFC, 0xFF94A3B8, 0xFF475569},
                null,
                Shader.TileMode.MIRROR
        ));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float pad = 2.5f * density;
        outerRect.set(pad, pad, w - pad, h - pad);
        canvas.drawRoundRect(outerRect, 18f * density, 18f * density, outerGlassPaint);
        canvas.drawRoundRect(outerRect, 18f * density, 18f * density, outerRimPaint);

        // Top Header Strip: AUDIO PROCESSING • PURIFICATION SUITE
        float innerPad = 10f * density;
        float topH = 20f * density;
        topHeaderRect.set(innerPad, pad + 5f * density, w - innerPad, pad + 5f * density + topH);
        canvas.drawRoundRect(topHeaderRect, 8f * density, 8f * density, headerPillPaint);
        canvas.drawRoundRect(topHeaderRect, 8f * density, 8f * density, subPanelBorderPaint);
        headerTextPaint.setColor(0xFF67E8F9);
        canvas.drawText("AUDIO PROCESSING • PURIFICATION SUITE", w * 0.5f,
                topHeaderRect.centerY() + 3f * density, headerTextPaint);

        // Layout Rows
        float footerH = 18f * density;
        footerRect.set(innerPad, h - pad - footerH - 4f * density, w - innerPad, h - pad - 4f * density);

        float contentTop = topHeaderRect.bottom + 6f * density;
        float contentBottom = footerRect.top - 5f * density;
        float contentH = Math.max(80f * density, contentBottom - contentTop);
        float topRowBottom = contentTop + contentH * 0.57f;

        // Top Row Left: 5 Illuminated Faders (BASS .. TREBLE)
        float splitX = innerPad + (w - innerPad * 2f) * 0.56f;
        faderBayRect.set(innerPad, contentTop, splitX - 3f * density, topRowBottom);
        compBayRect.set(splitX + 3f * density, contentTop, w - innerPad, topRowBottom);
        bottomBayRect.set(innerPad, topRowBottom + 5f * density, w - innerPad, contentBottom);

        canvas.drawRoundRect(faderBayRect, 10f * density, 10f * density, subPanelPaint);
        canvas.drawRoundRect(faderBayRect, 10f * density, 10f * density, subPanelBorderPaint);

        canvas.drawRoundRect(compBayRect, 10f * density, 10f * density, subPanelPaint);
        canvas.drawRoundRect(compBayRect, 10f * density, 10f * density, subPanelBorderPaint);

        canvas.drawRoundRect(bottomBayRect, 10f * density, 10f * density, subPanelPaint);
        canvas.drawRoundRect(bottomBayRect, 10f * density, 10f * density, subPanelBorderPaint);

        drawFiveFaders(canvas, faderBayRect);
        drawCompressorAndGates(canvas, compBayRect);
        drawBottomMasteringRow(canvas, bottomBayRect);

        // Footer Status Pill
        canvas.drawRoundRect(footerRect, 7f * density, 7f * density, headerPillPaint);
        canvas.drawRoundRect(footerRect, 7f * density, 7f * density, subPanelBorderPaint);
        boolean activeSuite = noiseGateOn || noiseReductionOn || autoGainOn || compRatio > 1.05f
                || hpfHz > 24 || lpfHz < 21000 || bassBoostDb > 0.1f || trebleClarityDb > 0.1f;
        String footerText;
        if (limiterEngaged) {
            footerText = String.format(Locale.US, "PEAK LIMITER PROTECT • DYNAMIC RANGE %dbit", bitDepth);
            headerTextPaint.setColor(0xFFFCA5A5);
        } else if (liveCompReductionDb > 0.8f) {
            footerText = String.format(Locale.US, "CLEAN PROCESSING ACTIVE (-%.1fdB COMP) • %dbit",
                    liveCompReductionDb, bitDepth);
            headerTextPaint.setColor(0xFF67E8F9);
        } else {
            footerText = activeSuite
                    ? String.format(Locale.US, "CLEAN PROCESSING ACTIVE • DYNAMIC RANGE %dbit", bitDepth)
                    : String.format(Locale.US, "PURIFICATION BYPASS • DYNAMIC RANGE %dbit", bitDepth);
            headerTextPaint.setColor(activeSuite ? 0xFF67E8F9 : 0xFF94A3B8);
        }
        canvas.drawText(footerText, w * 0.5f, footerRect.centerY() + 2.8f * density, headerTextPaint);
    }

    private void drawFiveFaders(Canvas canvas, RectF bay) {
        float padX = 8f * density;
        float colW = (bay.width() - padX * 2f) / 5f;
        float topY = bay.top + 14f * density;
        float trackTop = bay.top + 20f * density;
        float trackBottom = bay.bottom - 16f * density;
        float trackH = Math.max(24f * density, trackBottom - trackTop);

        for (int i = 0; i < 5; i++) {
            float cx = bay.left + padX + colW * (i + 0.5f);
            int accent = FADER_COLORS[i];

            faderHitRects[i].set(cx - colW * 0.48f, bay.top + 2f * density, cx + colW * 0.48f, bay.bottom - 2f * density);

            // Top label
            labelSmallPaint.setColor(0xFFE2E8F0);
            canvas.drawText(FADER_LABELS[i], cx, topY, labelSmallPaint);

            // Scale tick marks flanking track
            for (int t = 0; t <= 6; t++) {
                float ty = trackTop + (trackH * t / 6f);
                float tickW = (t == 3) ? 6.5f * density : 4.0f * density;
                canvas.drawLine(cx - tickW - 3.5f * density, ty, cx - 3.5f * density, ty, tickPaint);
                canvas.drawLine(cx + 3.5f * density, ty, cx + tickW + 3.5f * density, ty, tickPaint);
            }

            // Track recess
            float slotW = 3.6f * density;
            tempRect.set(cx - slotW * 0.5f, trackTop, cx + slotW * 0.5f, trackBottom);
            canvas.drawRoundRect(tempRect, 2f * density, 2f * density, trackBgPaint);

            // Illuminated fill from bottom/center
            float norm = (faderDb[i] + 12f) / 24f; // -12..+12 -> 0..1
            float capY = trackBottom - norm * trackH;
            trackGlowPaint.setColor(withAlpha(accent, 0xEE));
            tempRect.set(cx - slotW * 0.45f, capY, cx + slotW * 0.45f, trackBottom);
            canvas.drawRoundRect(tempRect, 2f * density, 2f * density, trackGlowPaint);

            // Metallic Fader Cap
            float capW = Math.min(18f * density, colW * 0.65f);
            float capH = 7.5f * density;
            tempRect.set(cx - capW * 0.5f, capY - capH * 0.5f, cx + capW * 0.5f, capY + capH * 0.5f);
            capBodyPaint.setColor(accent);
            canvas.drawRoundRect(tempRect, 2.5f * density, 2.5f * density, capBodyPaint);
            canvas.drawRoundRect(tempRect, 2.5f * density, 2.5f * density, capBorderPaint);
            canvas.drawLine(tempRect.left + 2.5f * density, capY, tempRect.right - 2.5f * density, capY, capLinePaint);

            // Live dB value underneath
            valueTinyPaint.setColor(Math.abs(faderDb[i]) > 0.2f ? accent : 0xFF94A3B8);
            String dbStr = Math.abs(faderDb[i]) < 0.2f
                    ? "0 dB"
                    : String.format(Locale.US, "%+.0f dB", faderDb[i]);
            canvas.drawText(dbStr, cx, bay.bottom - 4.5f * density, valueTinyPaint);
        }
    }

    private void drawCompressorAndGates(Canvas canvas, RectF bay) {
        float cx = bay.centerX();
        sectionTitlePaint.setColor(0xFFF1F5F9);
        canvas.drawText("COMPRESSOR", cx, bay.top + 12f * density, sectionTitlePaint);

        float leftCx = bay.left + bay.width() * 0.28f;
        float rightCx = bay.left + bay.width() * 0.72f;
        float knobCy = bay.top + bay.height() * 0.36f;
        float knobR = Math.min(13f * density, bay.width() * 0.14f);

        ratioHitRect.set(leftCx - 28f * density, bay.top + 10f * density,
                leftCx + 28f * density, knobCy + knobR + 18f * density);
        threshHitRect.set(rightCx - 28f * density, bay.top + 10f * density,
                rightCx + 28f * density, knobCy + knobR + 18f * density);

        float ratioNorm = (compRatio - 1f) / 7f; // 1..8
        String ratioTxt = String.format(Locale.US, "%.0f:1", compRatio);
        int compRingColor = liveCompReductionDb > 0.5f ? 0xFFF472B6 : 0xFF38BDF8;
        drawMiniKnob(canvas, leftCx, knobCy, knobR, ratioNorm, "RATIO", ratioTxt, compRingColor);

        float threshNorm = (compThresholdDb + 30f) / 30f; // -30..0
        String threshTxt = String.format(Locale.US, "%.0f dB", compThresholdDb);
        drawMiniKnob(canvas, rightCx, knobCy, knobR, threshNorm, "THRESH", threshTxt, 0xFF38BDF8);

        // Two Toggle Switches: NOISE GATE & NOISE REDUCTION
        float swY = bay.bottom - 22f * density;
        noiseGateHitRect.set(bay.left + 2f * density, swY - 14f * density,
                cx - 2f * density, bay.bottom);
        noiseRedHitRect.set(cx + 2f * density, swY - 14f * density,
                bay.right - 2f * density, bay.bottom);

        drawHardwareToggle(canvas, leftCx, swY, "NOISE GATE", noiseGateOn, 0xFF22D3EE);
        drawHardwareToggle(canvas, rightCx, swY, "NOISE RED", noiseReductionOn, 0xFFF472B6);
    }

    private void drawBottomMasteringRow(Canvas canvas, RectF bay) {
        // 7 columns evenly spaced: BASS BOOST, TREBLE CLARITY, STEREO WIDTH, LIMITER, AUTO GAIN, HPF, LPF
        float padX = 6f * density;
        float colW = (bay.width() - padX * 2f) / 7f;
        float cy = bay.top + bay.height() * 0.42f;
        float knobR = Math.min(12.2f * density, colW * 0.34f);

        float c0 = bay.left + padX + colW * 0.5f;
        float c1 = c0 + colW;
        float c2 = c1 + colW;
        float c3 = c2 + colW;
        float c4 = c3 + colW;
        float c5 = c4 + colW;
        float c6 = c5 + colW;

        float topH = bay.top;
        float botH = bay.bottom;
        bassBoostHitRect.set(c0 - colW * 0.5f, topH, c0 + colW * 0.5f, botH);
        trebleClarityHitRect.set(c1 - colW * 0.5f, topH, c1 + colW * 0.5f, botH);
        stereoWidthHitRect.set(c2 - colW * 0.5f, topH, c2 + colW * 0.5f, botH);
        limiterHitRect.set(c3 - colW * 0.5f, topH, c3 + colW * 0.5f, botH);
        autoGainHitRect.set(c4 - colW * 0.5f, topH, c4 + colW * 0.5f, botH);
        hpfHitRect.set(c5 - colW * 0.5f, topH, c5 + colW * 0.5f, botH);
        lpfHitRect.set(c6 - colW * 0.5f, topH, c6 + colW * 0.5f, botH);

        drawMiniKnob(canvas, c0, cy, knobR, bassBoostDb / 12f,
                "BASS +", String.format(Locale.US, "+%.1fdB", bassBoostDb), 0xFF38BDF8);

        drawMiniKnob(canvas, c1, cy, knobR, trebleClarityDb / 12f,
                "CLARITY", String.format(Locale.US, "+%.1fdB", trebleClarityDb), 0xFFD946EF);

        drawMiniKnob(canvas, c2, cy, knobR, stereoWidthPercent / 200f,
                "WIDTH", stereoWidthPercent + "%", 0xFF22D3EE);

        int limiterAccent = limiterEngaged ? 0xFFFF2E4D : 0xFFFB7185;
        drawMiniKnob(canvas, c3, cy, knobR, (limiterCeilingDb + 12f) / 12f,
                "LIMITER", String.format(Locale.US, "%.1fdB", limiterCeilingDb), limiterAccent);

        drawHardwareToggle(canvas, c4, cy + 2f * density, "AUTO GAIN", autoGainOn, 0xFF4ADE80);

        drawMiniKnob(canvas, c5, cy, knobR, (hpfHz - 20f) / 230f,
                "HPF", hpfHz + "Hz", 0xFF67E8F9);

        drawMiniKnob(canvas, c6, cy, knobR, (lpfHz - 8000f) / 14000f,
                "LPF", String.format(Locale.US, "%.0fkHz", lpfHz / 1000f), 0xFFA78BFA);
    }

    private void drawMiniKnob(
            Canvas canvas,
            float cx,
            float cy,
            float radius,
            float norm,
            String label,
            String valText,
            int accentColor) {
        float clamped = Math.max(0f, Math.min(1f, norm));
        int dots = 7;
        float dotRing = radius + 3.6f * density;
        for (int i = 0; i < dots; i++) {
            float f = (float) i / (dots - 1);
            float deg = -135f + f * 270f;
            double rad = Math.toRadians(deg - 90f);
            float dx = cx + (float) Math.cos(rad) * dotRing;
            float dy = cy + (float) Math.sin(rad) * dotRing;
            boolean active = f <= clamped + 0.02f;
            knobDotPaint.setColor(active ? accentColor : 0x4464748B);
            canvas.drawCircle(dx, dy, (active ? 1.4f : 1.0f) * density, knobDotPaint);
        }

        canvas.drawCircle(cx, cy + 1.4f * density, radius + 1f * density, knobShadowPaint);
        canvas.drawCircle(cx, cy, radius, knobMetalPaint);
        knobRimPaint.setColor(withAlpha(accentColor, 0xAA));
        canvas.drawCircle(cx, cy, radius, knobRimPaint);

        float deg = -135f + clamped * 270f;
        double rad = Math.toRadians(deg - 90f);
        canvas.drawLine(
                cx + (float) Math.cos(rad) * (radius * 0.25f),
                cy + (float) Math.sin(rad) * (radius * 0.25f),
                cx + (float) Math.cos(rad) * (radius * 0.84f),
                cy + (float) Math.sin(rad) * (radius * 0.84f),
                knobPointerPaint
        );

        labelSmallPaint.setColor(0xFFE2E8F0);
        canvas.drawText(label, cx, cy + radius + 11f * density, labelSmallPaint);
        valueTinyPaint.setColor(accentColor);
        canvas.drawText(valText, cx, cy + radius + 19f * density, valueTinyPaint);
    }

    private void drawHardwareToggle(
            Canvas canvas,
            float cx,
            float cy,
            String label,
            boolean isOn,
            int ledColor) {
        // Status LED above switch
        float ledY = cy - 11f * density;
        if (isOn) {
            ledHaloPaint.setColor(withAlpha(ledColor, 0x66));
            canvas.drawCircle(cx, ledY, 4.2f * density, ledHaloPaint);
        }
        ledPaint.setColor(isOn ? ledColor : 0xFF334155);
        canvas.drawCircle(cx, ledY, 2.2f * density, ledPaint);

        // Metal switch barrel
        float pillW = 22f * density;
        float pillH = 11f * density;
        tempRect.set(cx - pillW * 0.5f, cy - pillH * 0.5f, cx + pillW * 0.5f, cy + pillH * 0.5f);
        swSlotPaint.setColor(isOn ? withAlpha(ledColor, 0x55) : 0xAA0F172A);
        canvas.drawRoundRect(tempRect, pillH * 0.5f, pillH * 0.5f, swSlotPaint);
        canvas.drawRoundRect(tempRect, pillH * 0.5f, pillH * 0.5f, subPanelBorderPaint);

        float thumbX = isOn ? tempRect.right - pillH * 0.5f : tempRect.left + pillH * 0.5f;
        canvas.drawCircle(thumbX, cy, pillH * 0.38f, swKnobPaint);

        labelSmallPaint.setColor(0xFFE2E8F0);
        canvas.drawText(label, cx, cy + pillH * 0.5f + 8.5f * density, labelSmallPaint);
        valueTinyPaint.setColor(isOn ? ledColor : 0xFF64748B);
        canvas.drawText(isOn ? "ON" : "OFF", cx, cy + pillH * 0.5f + 16f * density, valueTinyPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        float x = event.getX();
        float y = event.getY();

        if (action == MotionEvent.ACTION_DOWN) {
            activeTarget = hitTestTarget(x, y);
            if (activeTarget == TARGET_NONE) {
                return super.onTouchEvent(event);
            }
            if (getParent() != null) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            lastTouchY = y;

            // Toggles respond immediately on tap
            if (activeTarget == TARGET_SW_NOISE_GATE) {
                noiseGateOn = !noiseGateOn;
                invalidate();
                if (listener != null) listener.onNoiseGateToggled(noiseGateOn);
                activeTarget = TARGET_NONE;
                return true;
            } else if (activeTarget == TARGET_SW_NOISE_REDUCTION) {
                noiseReductionOn = !noiseReductionOn;
                invalidate();
                if (listener != null) listener.onNoiseReductionToggled(noiseReductionOn);
                activeTarget = TARGET_NONE;
                return true;
            } else if (activeTarget == TARGET_SW_AUTO_GAIN) {
                autoGainOn = !autoGainOn;
                invalidate();
                if (listener != null) listener.onAutoGainToggled(autoGainOn);
                activeTarget = TARGET_NONE;
                return true;
            }

            // Double-tap reset for knobs/faders
            long now = SystemClock.uptimeMillis();
            if (lastTapTarget == activeTarget && (now - lastTapMs) < 300L) {
                resetTargetToDefault(activeTarget);
                lastTapMs = 0L;
            } else {
                lastTapTarget = activeTarget;
                lastTapMs = now;
            }
            if (activeTarget >= TARGET_FADER_BASE && activeTarget < TARGET_FADER_BASE + 5) {
                updateFaderFromY(activeTarget - TARGET_FADER_BASE, y);
            }
            return true;
        } else if (action == MotionEvent.ACTION_MOVE && activeTarget != TARGET_NONE) {
            if (activeTarget >= TARGET_FADER_BASE && activeTarget < TARGET_FADER_BASE + 5) {
                updateFaderFromY(activeTarget - TARGET_FADER_BASE, y);
            } else {
                float dy = lastTouchY - y;
                lastTouchY = y;
                if (Math.abs(dy) >= 0.6f) {
                    applyDragDelta(activeTarget, dy);
                }
            }
            return true;
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            activeTarget = TARGET_NONE;
            if (getParent() != null) {
                getParent().requestDisallowInterceptTouchEvent(false);
            }
            return true;
        }
        return super.onTouchEvent(event);
    }

    private int hitTestTarget(float x, float y) {
        for (int i = 0; i < 5; i++) {
            if (faderHitRects[i].contains(x, y)) return TARGET_FADER_BASE + i;
        }
        if (ratioHitRect.contains(x, y)) return TARGET_KNOB_RATIO;
        if (threshHitRect.contains(x, y)) return TARGET_KNOB_THRESH;
        if (noiseGateHitRect.contains(x, y)) return TARGET_SW_NOISE_GATE;
        if (noiseRedHitRect.contains(x, y)) return TARGET_SW_NOISE_REDUCTION;
        if (bassBoostHitRect.contains(x, y)) return TARGET_KNOB_BASS_BOOST;
        if (trebleClarityHitRect.contains(x, y)) return TARGET_KNOB_TREBLE_CLARITY;
        if (stereoWidthHitRect.contains(x, y)) return TARGET_KNOB_STEREO_WIDTH;
        if (limiterHitRect.contains(x, y)) return TARGET_KNOB_LIMITER;
        if (autoGainHitRect.contains(x, y)) return TARGET_SW_AUTO_GAIN;
        if (hpfHitRect.contains(x, y)) return TARGET_KNOB_HPF;
        if (lpfHitRect.contains(x, y)) return TARGET_KNOB_LPF;
        return TARGET_NONE;
    }

    private void updateFaderFromY(int idx, float y) {
        float trackTop = faderBayRect.top + 20f * density;
        float trackBottom = faderBayRect.bottom - 16f * density;
        float norm = 1f - ((y - trackTop) / Math.max(1f, trackBottom - trackTop));
        norm = Math.max(0f, Math.min(1f, norm));
        float newDb = Math.round((-12f + norm * 24f) * 2f) / 2f;
        if (Math.abs(faderDb[idx] - newDb) > 0.05f) {
            faderDb[idx] = newDb;
            invalidate();
            if (listener != null) listener.onFaderChanged(idx, newDb);
        }
    }

    private void applyDragDelta(int target, float dy) {
        float normDelta = dy / (110f * density);
        switch (target) {
            case TARGET_KNOB_RATIO:
                compRatio = Math.max(1f, Math.min(8f, compRatio + normDelta * 7f));
                invalidate();
                if (listener != null) listener.onCompressorChanged(compRatio, compThresholdDb);
                break;
            case TARGET_KNOB_THRESH:
                compThresholdDb = Math.max(-30f, Math.min(0f, compThresholdDb + normDelta * 30f));
                invalidate();
                if (listener != null) listener.onCompressorChanged(compRatio, compThresholdDb);
                break;
            case TARGET_KNOB_BASS_BOOST:
                bassBoostDb = Math.max(0f, Math.min(12f, bassBoostDb + normDelta * 12f));
                invalidate();
                if (listener != null) listener.onPurificationBassChanged(bassBoostDb);
                break;
            case TARGET_KNOB_TREBLE_CLARITY:
                trebleClarityDb = Math.max(0f, Math.min(12f, trebleClarityDb + normDelta * 12f));
                invalidate();
                if (listener != null) listener.onTrebleClarityChanged(trebleClarityDb);
                break;
            case TARGET_KNOB_STEREO_WIDTH:
                stereoWidthPercent = Math.max(0, Math.min(200, stereoWidthPercent + Math.round(normDelta * 200f)));
                invalidate();
                if (listener != null) listener.onStereoWidthChanged(stereoWidthPercent);
                break;
            case TARGET_KNOB_LIMITER:
                limiterCeilingDb = Math.max(-12f, Math.min(0f, limiterCeilingDb + normDelta * 12f));
                invalidate();
                if (listener != null) listener.onLimiterChanged(limiterCeilingDb);
                break;
            case TARGET_KNOB_HPF:
                hpfHz = Math.max(20, Math.min(250, hpfHz + Math.round(normDelta * 230f)));
                invalidate();
                if (listener != null) listener.onHpfChanged(hpfHz);
                break;
            case TARGET_KNOB_LPF:
                lpfHz = Math.max(8000, Math.min(22000, lpfHz + Math.round(normDelta * 14000f)));
                invalidate();
                if (listener != null) listener.onLpfChanged(lpfHz);
                break;
            default:
                break;
        }
    }

    private void resetTargetToDefault(int target) {
        if (target >= TARGET_FADER_BASE && target < TARGET_FADER_BASE + 5) {
            int idx = target - TARGET_FADER_BASE;
            faderDb[idx] = 0f;
            invalidate();
            if (listener != null) listener.onFaderChanged(idx, 0f);
            return;
        }
        switch (target) {
            case TARGET_KNOB_RATIO:
                compRatio = 3.0f;
                invalidate();
                if (listener != null) listener.onCompressorChanged(compRatio, compThresholdDb);
                break;
            case TARGET_KNOB_THRESH:
                compThresholdDb = -12.0f;
                invalidate();
                if (listener != null) listener.onCompressorChanged(compRatio, compThresholdDb);
                break;
            case TARGET_KNOB_BASS_BOOST:
                bassBoostDb = 3.0f;
                invalidate();
                if (listener != null) listener.onPurificationBassChanged(bassBoostDb);
                break;
            case TARGET_KNOB_TREBLE_CLARITY:
                trebleClarityDb = 2.5f;
                invalidate();
                if (listener != null) listener.onTrebleClarityChanged(trebleClarityDb);
                break;
            case TARGET_KNOB_STEREO_WIDTH:
                stereoWidthPercent = 120;
                invalidate();
                if (listener != null) listener.onStereoWidthChanged(stereoWidthPercent);
                break;
            case TARGET_KNOB_LIMITER:
                limiterCeilingDb = -1.0f;
                invalidate();
                if (listener != null) listener.onLimiterChanged(limiterCeilingDb);
                break;
            case TARGET_KNOB_HPF:
                hpfHz = 80;
                invalidate();
                if (listener != null) listener.onHpfChanged(hpfHz);
                break;
            case TARGET_KNOB_LPF:
                lpfHz = 18000;
                invalidate();
                if (listener != null) listener.onLpfChanged(lpfHz);
                break;
            default:
                break;
        }
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }
}
